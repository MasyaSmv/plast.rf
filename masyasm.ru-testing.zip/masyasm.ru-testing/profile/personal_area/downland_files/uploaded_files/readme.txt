The uploaded files will be placed in this directory.
