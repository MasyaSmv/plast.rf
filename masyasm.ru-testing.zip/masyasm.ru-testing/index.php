<!DOCTYPE html>
<html lang="ru">
	<head>
		<title>MasyaSmerd</title>
	</head>

	<body>
		<?php
			require_once("header.php");
		?>



	<div class="container-fluid" style="padding-top: 6em;">
		<div class="m35Hf9" style="text-align: center; padding-bottom: 2em;">
		<h1>Допро пожаловать на мой сайт))</h1>
		<h2>Пока этот сайт только делается, но в будущем тут будут собраны все мои личные проекты.</h2>
		<h3>Сейчас дорабатывается личный кабинет, по этому можете пока послушать акульи звуки :3</h3>
		</div>
		<div class="o3O90" style="text-align: center;">
		<iframe class="iframegura" src="https://www.youtube.com/embed/RNfHTuL2sPU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			</div>

		<?php
// 			require_once("footer.php");
echo "\n Некоторая отладочная информация:";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";
		?>

	</body>
</html>
