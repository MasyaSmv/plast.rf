<div id="footer">
	<p>Подвал сайта</p>
</div>